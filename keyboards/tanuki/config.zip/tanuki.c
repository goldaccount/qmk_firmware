#include "rev2/tanuki.h"
#include "config.h"

void matrix_init_kb(void) {
	// put your keyboard start-up code here
	// runs once when the firmware starts up

};
